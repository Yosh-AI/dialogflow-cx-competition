## Development server
- install node.js runtime
- type `npm install`
- type `npm install -g @angular/cli`
- type `ng serve` for a dev server
- navigate to `http://localhost:4200/`

## How to use
- on mobile device go to[google-maps-mock](https://cx-covid19-bot.web.app/)
- click on "Chat" 









