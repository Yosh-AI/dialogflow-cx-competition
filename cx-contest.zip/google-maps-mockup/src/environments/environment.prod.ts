export const environment = {
  production: true,
  
  buildVersion: '<version>',
  buildNumber: '<build_number>',
  buildDate: '<date>',
};
