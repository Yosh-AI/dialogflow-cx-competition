$(document).ready(function(){
  $('.sidenav').sidenav();
});
$(document).ready(function(){
  $('select').formSelect();
});
