export class FirestoreDTO {
  timestamp: Date;
  liveAgent: boolean;
  businessMessageConvId: string;
}
