export interface DFReqBody {
  session,
  queryParams,
  queryInput
}
